
youngtrip

#＃ docker-django
### docker run -it --rm --network my-net -p 0.0.0.0:8000:8000 -v $(pwd)/src:/app --name youngtrip youngtrip bash

## RabbitMQ
### docker run -it --rm --network my-net --hostname localhost  -p 15672:15672 -p 5672:5672 -e RABBITMQ_DEFAULT_USER=root -e RABBITMQ_DEFAULT_PASS=w9jTwtNi1wm4Q3VPUfBecPWd --name myrabbit rabbitmq:3.8.2-management

## redis
###  docker run -it --rm --network my-net  -p 6379:6379 --name myredis redis:latest
### Django-reds操作
```
from django.core.cache import cache 
cache.set(key, value, timeout=30*60)  #这里是30分钟, 参数nx=True有限支持原子操作    
cache.has_key('key')
cache.get('key')
cache.keys("foo_*")　＃扫描keys
cache.delete_pattern("foo_*")　＃支持通配符
cache.ttl("foo")　　＃获取过期时间
```

## celery
### celery -A youngtrip worker -l info

## flow
### celery  flower  -A youngtrip  --basic_auth=root:w9jTwtNi1wm4Q3VPUfBecPWd --broker=amqp://root:w9jTwtNi1wm4Q3VPUfBecPWd@myrabbit:5672// --address=0.0.0.0  -port=5555